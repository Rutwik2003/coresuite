package net.rocky.coresuite.module.customfishing;

import net.rocky.coresuite.CoreSuitePlugin;
import net.rocky.coresuite.common.text.TextUtil;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;

import java.util.ArrayList;
import java.util.List;

public class FishingEnchantManager {

    public enum CustomEnchant {
        LURE_OF_THE_DEEP("Lure of the Deep", 3, "lure_of_the_deep", "coresuite_enchant_lure_of_the_deep"),
        HEAVYWEIGHT("Heavyweight", 5, "heavyweight", "coresuite_enchant_heavyweight"),
        DOUBLE_HOOK("Double Hook", 3, "double_hook", "coresuite_enchant_double_hook"),
        TREASURE_HUNTER("Treasure Hunter", 3, "treasure_hunter", "coresuite_enchant_treasure_hunter");

        private final String displayName;
        private final int maxLevel;
        private final String configKey;
        private final String keyString;

        CustomEnchant(String displayName, int maxLevel, String configKey, String keyString) {
            this.displayName = displayName;
            this.maxLevel = maxLevel;
            this.configKey = configKey;
            this.keyString = keyString;
        }

        public String getDisplayName() { return displayName; }
        public int getMaxLevel() { return maxLevel; }
        public String getConfigKey() { return configKey; }
        public String getKeyString() { return keyString; }
    }

    private final CoreSuitePlugin plugin;

    public FishingEnchantManager(CoreSuitePlugin plugin) {
        this.plugin = plugin;
    }

    public NamespacedKey getKey(CustomEnchant enchant) {
        return new NamespacedKey(plugin, enchant.getKeyString());
    }

    public int getEnchantLevel(ItemStack item, CustomEnchant enchant) {
        if (item == null || item.getType() == Material.AIR || !item.hasItemMeta()) return 0;
        return item.getItemMeta().getPersistentDataContainer().getOrDefault(getKey(enchant), PersistentDataType.INTEGER, 0);
    }

    public void setEnchantLevel(ItemStack item, CustomEnchant enchant, int level) {
        if (item == null || item.getType() == Material.AIR) return;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;
        
        meta.getPersistentDataContainer().set(getKey(enchant), PersistentDataType.INTEGER, level);
        item.setItemMeta(meta);
        updateLore(item);
    }
    
    public void updateLore(ItemStack item) {
        if (item == null || item.getType() == Material.AIR || !item.hasItemMeta()) return;
        ItemMeta meta = item.getItemMeta();
        List<Component> newLore = new ArrayList<>();
        
        List<Component> oldLore = meta.lore();
        if (oldLore != null) {
            for (Component c : oldLore) {
                String plain = PlainTextComponentSerializer.plainText().serialize(c);
                boolean isCustomEnchant = false;
                for (CustomEnchant ce : CustomEnchant.values()) {
                    if (plain.contains(ce.getDisplayName())) {
                        isCustomEnchant = true;
                        break;
                    }
                }
                if (!isCustomEnchant) {
                    newLore.add(c);
                }
            }
        }
        
        for (CustomEnchant ce : CustomEnchant.values()) {
            int level = getEnchantLevel(item, ce);
            if (level > 0) {
                newLore.add(0, TextUtil.colorize("&7" + ce.getDisplayName() + " " + toRoman(level)));
            }
        }
        
        meta.lore(newLore);
        item.setItemMeta(meta);
    }
    
    private String toRoman(int number) {
        return switch (number) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            default -> String.valueOf(number);
        };
    }
}
