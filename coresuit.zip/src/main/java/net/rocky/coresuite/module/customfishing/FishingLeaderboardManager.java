package net.rocky.coresuite.module.customfishing;

import net.rocky.coresuite.CoreSuitePlugin;
import net.rocky.coresuite.common.gui.Gui;
import net.rocky.coresuite.common.gui.GuiButton;
import net.rocky.coresuite.common.text.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

public class FishingLeaderboardManager {

    private final CoreSuitePlugin plugin;
    private final CustomFishingModule module;
    private final Map<String, Double> serverRecords = new ConcurrentHashMap<>();

    public FishingLeaderboardManager(CoreSuitePlugin plugin, CustomFishingModule module) {
        this.plugin = plugin;
        this.module = module;
        loadServerRecords();
    }

    private void loadServerRecords() {
        plugin.getDatabaseManager().executeAsync(() -> {
            try (Connection conn = plugin.getDatabaseManager().getConnection();
                 PreparedStatement stmt = conn.prepareStatement("SELECT species_id, MAX(max_weight) as absolute_max FROM coresuite_fish_logbook GROUP BY species_id")) {
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        serverRecords.put(rs.getString("species_id"), rs.getDouble("absolute_max"));
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load fishing server records", e);
            }
        });
    }

    public void checkServerRecord(Player player, String speciesId, double weight, String chatName) {
        double currentRecord = serverRecords.getOrDefault(speciesId, 0.0);
        if (weight > currentRecord) {
            serverRecords.put(speciesId, weight);
            String prefix = plugin.getConfig().getString("modules.custom-fishing.prefix", "&8[&b&lFishing&8] &r");
            Bukkit.broadcast(TextUtil.colorize(prefix + "&e&lSERVER RECORD! &f" + player.getName() + " &7caught a &e" + chatName + " &7weighing &b" + weight + " kg&7!"));
        }
    }

    public void openTopGUI(Player player) {
        openTopGUI(player, 0);
    }

    public void openTopGUI(Player player, int page) {
        Gui gui = new Gui("&8Fishing Leaderboards", 6);
        gui.fillBorder(Material.GRAY_STAINED_GLASS_PANE);
        
        if (module.getConfig().getConfigurationSection("species") != null) {
            List<String> keys = new ArrayList<>(module.getConfig().getConfigurationSection("species").getKeys(false));
            int totalItems = keys.size();
            int itemsPerPage = 28;
            int totalPages = (int) Math.ceil((double) totalItems / itemsPerPage);
            if (totalPages == 0) totalPages = 1;
            
            int startIndex = page * itemsPerPage;
            int endIndex = Math.min(startIndex + itemsPerPage, totalItems);
            
            int slot = 10;
            for (int i = startIndex; i < endIndex; i++) {
                String key = keys.get(i);
                String spPath = "species." + key + ".";
                try {
                    String name = module.getConfig().getString(spPath + "name", "");
                    String materialName = module.getConfig().getString(spPath + "material", "COD");
                    String itemModel = module.getConfig().getString(spPath + "item-model", "");
                    int cmd = module.getConfig().getInt(spPath + "custom-model-data", -1);
                
                    String speciesId = org.bukkit.ChatColor.stripColor(org.bukkit.ChatColor.translateAlternateColorCodes('&', name));
                
                    Material mat = Material.COD;
                    try {
                        mat = Material.valueOf(materialName.toUpperCase());
                    } catch (Exception ignored) {}
                
                    ItemStack icon = new ItemStack(mat);
                    ItemMeta meta = icon.getItemMeta();
                    if (meta != null) {
                        meta.displayName(TextUtil.colorize(name + " &7Leaderboard"));
                        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
                        lore.add(TextUtil.colorize("&7Click to view the top 10"));
                        lore.add(TextUtil.colorize("&7heaviest catches for this fish."));
                        lore.add(net.kyori.adventure.text.Component.empty());
                        double record = serverRecords.getOrDefault(speciesId, 0.0);
                        lore.add(TextUtil.colorize("&eServer Record: &f" + record + " kg"));
                        meta.lore(lore);
                    
                        if (!itemModel.isEmpty()) {
                            meta.setItemModel(NamespacedKey.fromString(itemModel));
                        }
                        if (cmd != -1) {
                            meta.setCustomModelData(cmd);
                        }
                        icon.setItemMeta(meta);
                    }
                
                    gui.setItem(slot, new GuiButton(icon, e -> openSpeciesLeaderboard(player, speciesId, name, icon)));
                
                    slot++;
                    while (slot % 9 == 0 || slot % 9 == 8) slot++;
                } catch (Exception ignored) {}
            }
            
            if (page > 0) {
                gui.setItem(45, GuiButton.of(Material.ARROW, "&aPrevious Page", java.util.Arrays.asList("&7Go to page " + page), e -> openTopGUI(player, page - 1)));
            }
            if (page < totalPages - 1) {
                gui.setItem(53, GuiButton.of(Material.ARROW, "&aNext Page", java.util.Arrays.asList("&7Go to page " + (page + 2)), e -> openTopGUI(player, page + 1)));
            }
        }
        gui.setItem(49, GuiButton.of(Material.BARRIER, "&c&lBack", java.util.Arrays.asList("&7Return to main menu."), e -> player.performCommand("fish")));
        gui.open(player);
    }

    private void openSpeciesLeaderboard(Player player, String speciesId, String chatName, ItemStack icon) {
        player.sendMessage(TextUtil.colorize("&7Loading leaderboard for " + chatName + "&7..."));
        
        plugin.getDatabaseManager().executeAsync(() -> {
            try (Connection conn = plugin.getDatabaseManager().getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                     "SELECT l.uuid, l.max_weight, f.player_name FROM coresuite_fish_logbook l " +
                     "LEFT JOIN coresuite_fishing f ON l.uuid = f.uuid " +
                     "WHERE l.species_id = ? ORDER BY l.max_weight DESC LIMIT 10")) {
                stmt.setString(1, speciesId);
                try (ResultSet rs = stmt.executeQuery()) {
                    
                    List<String> lines = new ArrayList<>();
                    lines.add("\u00268\u0026m══════════════════════════════");
                    lines.add("  " + chatName + " \u0026eLeaderboard");
                    lines.add("\u00268\u0026m══════════════════════════════");
                    
                    int rank = 1;
                    while (rs.next()) {
                        double weight = rs.getDouble("max_weight");
                        String name = rs.getString("player_name");
                        if (name == null) name = "Unknown";
                        
                        String color = "\u00267";
                        if (rank == 1) color = "\u0026e#1 ";
                        if (rank == 2) color = "\u00266#2 ";
                        if (rank == 3) color = "\u0026c#3 ";
                        if (rank > 3) color = "\u00268#" + rank + " ";
                        
                        lines.add(color + "\u0026f" + name + " \u00267- \u0026b" + weight + " kg");
                        rank++;
                    }
                    
                    if (rank == 1) {
                        lines.add("\u00267No one has caught this fish yet!");
                    }
                    lines.add("\u00268\u0026m══════════════════════════════");
                    
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        for (String line : lines) {
                            player.sendMessage(TextUtil.colorize(line));
                        }
                    });
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load leaderboard for " + speciesId, e);
                Bukkit.getScheduler().runTask(plugin, () -> player.sendMessage(TextUtil.colorize("\u0026cFailed to load leaderboard.")));
            }
        });
    }
}



