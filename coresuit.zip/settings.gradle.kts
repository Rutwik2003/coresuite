rootProject.name = "CoreSuite"
